// A la quête d'Onyx - PS Vita (vita2d) - cadeau d'anniversaire pour Keï
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <vita2d.h>
#include <psp2/gxm.h>
#include <psp2/ctrl/ctrl.h>
#include <psp2/audioout.h>
#include <psp2/kernel/threadmgr.h>
#include <psp2/kernel/processmgr.h>

#define SW 960
#define SH 544
#define GTOP 230
#define GBOT 372
#define RGB(r,g,b) RGBA8(r,g,b,255)
#define R(x,y,w,h,c) vita2d_draw_rectangle((x),(y),(w),(h),(c))
#define DT (1.0f/60.0f)

/* ---------------- textures ---------------- */
enum {K_FRONT,K_SIDE,K_W0,K_W1,K_W2,K_W3,K_R0,K_R1,K_R2,K_R3,K_SELFIE,O_SIT,O_W0,O_W1,O_W2,O_W3,
      O_R0,O_R1,O_R2,O_R3,O_FACE,O_LICK,KO_HOLD,KO_PET,KO_SELFIE,KO_SIT,KO_WALK,E_IDLE,E_W0,E_W1,PFP,NT};
static const char *TN[NT]={"k_front","k_side","k_walk0","k_walk1","k_walk2","k_walk3","k_run0","k_run1","k_run2","k_run3",
 "k_selfie","o_sit","o_walk0","o_walk1","o_walk2","o_walk3","o_run0","o_run1","o_run2","o_run3","o_face","o_lick",
 "ko_hold","ko_pet","ko_selfie","ko_sit","ko_walk","e_idle","e_walk0","e_walk1","pfp"};
static vita2d_texture *T[NT];
static vita2d_pgf *F;

static void spr(int t,float cx,float feet,int flip,float sc){
  if(!T[t])return;
  float w=vita2d_texture_get_width(T[t]),h=vita2d_texture_get_height(T[t]);
  if(flip) vita2d_draw_texture_scale(T[t],cx+w*sc/2,feet-h*sc,-sc,sc);
  else vita2d_draw_texture_scale(T[t],cx-w*sc/2,feet-h*sc,sc,sc);
}
static void txt(float x,float y,unsigned c,float s,const char*t){vita2d_pgf_draw_text(F,x,y,c,s,t);}
static float tw(float s,const char*t){return vita2d_pgf_text_width(F,s,t);}
static void ctxt(float cx,float y,unsigned c,float s,const char*t){txt(cx-tw(s,t)/2,y,c,s,t);}
static void heart(float x,float y,float s,unsigned c){
  static const char*h[]={".XX.XX.","XXXXXXX","XXXXXXX",".XXXXX.","..XXX..","...X..."};
  for(int r=0;r<6;r++)for(int q=0;q<7;q++)if(h[r][q]=='X')R(x+q*s,y+r*s,s,s,c);
}

/* ---------------- audio ---------------- */
static int16_t *wav[8]; static int wlen[8];
static volatile int cur_bgm=0, sfx_req=-1;
static int16_t *loadwav(const char*n,int*len){
  char p[96]; snprintf(p,96,"app0:assets/%s",n);
  FILE*f=fopen(p,"rb"); *len=0; if(!f)return NULL;
  fseek(f,0,SEEK_END); long sz=ftell(f); fseek(f,44,SEEK_SET);
  int bytes=(int)(sz-44); int16_t*b=(int16_t*)malloc(bytes+4096);
  if(!b){fclose(f);return NULL;}
  memset(b,0,bytes+4096); fread(b,1,bytes,f); fclose(f); *len=bytes/2; return b;
}
static int bgm_thread(SceSize a,void*argp){
  int port=sceAudioOutOpenPort(SCE_AUDIO_OUT_PORT_TYPE_MAIN,1024,22050,SCE_AUDIO_OUT_MODE_MONO);
  int vol[2]={13000,13000};
  sceAudioOutSetVolume(port,SCE_AUDIO_VOLUME_FLAG_L_CH|SCE_AUDIO_VOLUME_FLAG_R_CH,vol);
  static int16_t sil[1024]; int pos=0,last=-1;
  while(1){
    int b=cur_bgm; if(b!=last){pos=0;last=b;}
    if(!wav[b]||wlen[b]<2048){sceAudioOutOutput(port,sil);continue;}
    if(pos+1024>wlen[b])pos=0;
    sceAudioOutOutput(port,wav[b]+pos); pos+=1024;
  }
  return 0;
}
static int sfx_thread(SceSize a,void*argp){
  int port=sceAudioOutOpenPort(SCE_AUDIO_OUT_PORT_TYPE_MAIN,1024,22050,SCE_AUDIO_OUT_MODE_MONO);
  int vol[2]={26000,26000};
  sceAudioOutSetVolume(port,SCE_AUDIO_VOLUME_FLAG_L_CH|SCE_AUDIO_VOLUME_FLAG_R_CH,vol);
  static int16_t sil[1024];
  while(1){
    int s=sfx_req;
    if(s>=0&&wav[2+s]){ sfx_req=-1; int n=wlen[2+s]; for(int p=0;p<n;p+=1024){
        static int16_t g[1024]; memset(g,0,sizeof(g)); int c=n-p; if(c>1024)c=1024; memcpy(g,wav[2+s]+p,c*2);
        sceAudioOutOutput(port,g);} }
    else { sfx_req=-1; sceAudioOutOutput(port,sil); }
  }
  return 0;
}
static void sfx(int i){sfx_req=i;} /* 0 blip, 1 jump, 2 item */

/* ---------------- input ---------------- */
static SceCtrlData pad; static unsigned prev,pr; static float ax,ay;
static void input(void){
  sceCtrlPeekBufferPositive(0,&pad,1);
  pr=pad.buttons&~prev; prev=pad.buttons;
  ax=(pad.lx-128)/128.f; ay=(pad.ly-128)/128.f;
  if(fabsf(ax)<0.2f)ax=0; if(fabsf(ay)<0.2f)ay=0;
  if(pad.buttons&SCE_CTRL_LEFT)ax=-1; if(pad.buttons&SCE_CTRL_RIGHT)ax=1;
  if(pad.buttons&SCE_CTRL_UP)ay=-1; if(pad.buttons&SCE_CTRL_DOWN)ay=1;
}
#define OK (pr&(SCE_CTRL_CROSS|SCE_CTRL_CIRCLE))

/* ---------------- dialogues ---------------- */
typedef struct{int who;const char*t;}L;
static const char*SPK[]={"Keï","Esteban","","Gabin","Salvador","Maël","Maël Querard","Sasha","Léo"};

static const L iA[]={{0,"Hmm... quoi ?! Il est où quoi... Onyx a disparu ?!"},{0,NULL}};
static const L iB[]={
 {1,"Keï ? Je t'ai entendue crier depuis le couloir, ça va ?"},
 {0,"Esteban ! J'ai perdu mon chat Onyx... Il s'est enfui !"},
 {1,"Onyx ? Ton petit chat noir ? Il ne doit pas être loin."},
 {0,"Il dormait sur moi, et d'un coup il a filé comme l'éclair..."},
 {1,"Ne t'inquiète pas Boubouille, on va le retrouver ensemble."},
 {0,"Merci mon amour... On commence par la chambre ?"},
 {1,"Allez, c'est parti pour la quête d'Onyx !"},{0,NULL}};
static const L o0[]={
 {1,"Des poils noirs partout, mais pas d'Onyx dans la chambre..."},
 {0,"Il a dû sortir ! Cherchons dehors, dans mon quartier."},
 {1,"Direction la rue de Bouguenais !"},{0,NULL}};
static const L i0[]={{1,"Cherchons des indices dans la chambre. Onyx a laissé des poils noirs partout !"},{0,NULL}};
static const L i1[]={{2,"Bouguenais. Le soleil se couche, des gâteaux d'anniversaire traînent un peu partout."},
 {0,"Bizarre... pourquoi y a des gâteaux partout ?"},{1,"Euh... aucune idée ! Cherchons plutôt des croquettes d'Onyx."},{0,NULL}};
static const L n1[]={
 {3,"Salut la Boubouille ! Salut Esteban ! Vous en faites une tête."},
 {0,"Gabin ! Onyx a disparu, tu l'aurais pas vu ?"},
 {3,"Non, mais avec mon très long sabre je peux fendre les buissons."},
 {1,"Euh... non merci, on veut le retrouver entier."},
 {3,"Ah oui, bien sûr ! Alors essayez le parc, Salvador y lit ses bouquins."},
 {3,"Et fais attention, Keï, les chats adorent se cacher dans les endroits bizarres."},{0,NULL}};
static const L o1[]={{1,"Ça fait cinq croquettes ! Onyx est passé par ici."},{0,"Direction le parc !"},{0,NULL}};
static const L i2[]={{2,"Le parc de la ville. La lune brille entre les arbres."},{0,"Onyx ? Onyyyx ?"},{1,"Miaou ? ... Non, rien."},{0,NULL}};
static const L n2[]={
 {4,"Bonsoir ! Statistiquement, un chat perdu se cache à moins de 300 mètres."},
 {0,"Salvador, on a déjà cherché dans toute la rue..."},
 {4,"Alors il est soit très loin, soit très près. C'est mathématique."},
 {1,"Super, merci, ça nous avance beaucoup."},
 {4,"Je vous propose un entraînement : attrapez les gâteaux qui tombent, ça aiguise les réflexes !"},
 {4,"Mais évitez les bières de Maël Querard, elles tombent aussi."},{0,NULL}};
static const L o2[]={{0,"On a trouvé des empreintes de patte qui filent vers le tram !"},{1,"Alors on file en ville, à Nantes !"},{0,NULL}};
static const L i3[]={{2,"Dans le tram direction Nantes, comme à chaque soirée."},{1,"Tu te rappelles notre première sortie en ville ?"},{0,"Comment l'oublier... Chut, cherchons des indices."},{0,NULL}};
static const L n3[]={
 {7,"Keï ! Esteban ! Vous aussi vous allez en ville ?"},
 {0,"Sasha ! On cherche Onyx, il s'est enfui ce matin."},
 {7,"Oh non ! Les chats ont leurs petits secrets, tu sais."},
 {7,"Ce soir tout le monde sera au Café du cinéma. Peut-être qu'un ami l'a vu."},
 {1,"Parfait, on y va. Merci Sasha !"},{0,NULL}};
static const L o3[]={{1,"Prochain arrêt : Nantes centre. Descendons !"},{0,NULL}};
static const L i4[]={{2,"Nantes, ses rues pavées et ses lumières chaudes."},{0,"J'adore cette ville la nuit."},{1,"Moi j'adore surtout y être avec toi."},{0,NULL}};
static const L n4[]={
 {5,"Oh, la Boubouille ! Ton look est parfait ce soir, j'adore la robe blanche."},
 {0,"Merci Maël ! Mais j'ai un souci, Onyx a disparu."},
 {5,"Un chat noir sans accessoire ? Le drame de la mode."},
 {1,"Maël, concentre-toi : tu l'as vu ou pas ?"},
 {5,"Non mais j'ai vu Léo et Maël Querard entrer au Café du cinéma."},
 {5,"Avant ça, un petit défi : retiens les pas d'Onyx, c'est un jeu de mémoire !"},{0,NULL}};
static const L o4[]={{0,"On a réussi le défi des pas ! Allons au Café du cinéma."},{1,"Je te suis, ma Boubouille."},{0,NULL}};
static const L i5[]={{2,"Le Café du cinéma, un bar de Nantes plein de lumières, de néons et de gâteaux d'anniversaire."},
 {0,"Il y a des bougies partout ! C'est joli..."},{1,"Hmm, curieux hasard. Cherchons plutôt Onyx."},{0,NULL}};
static const L n5a[]={
 {6,"Hé ! La team est là ! Une bière pour la route ?"},
 {0,"Maël Querard, pas ce soir. On cherche Onyx."},
 {6,"Ton chat noir ? Je l'ai pas vu, mais j'ai vu une ombre vers la Loire."},
 {1,"Une ombre ? Intéressant, merci."},{0,NULL}};
static const L n5b[]={
 {8,"Yo ! Santé ! Keï, pourquoi tu fais cette tête ?"},
 {0,"Léo, Onyx s'est enfui, on le cherche partout."},
 {8,"Respire ! Tiens, mange un bout de gâteau, ça va aller."},
 {1,"Léo, chut ! C'était pour plus tard !"},
 {8,"Oups... j'ai rien dit. Allez voir au château, il paraît qu'un chat noir y traîne."},{0,NULL}};
static const L o5[]={{0,"Merci les gars, on file au château !"},{1,"Et ne parlez à personne de ce qui est dans ce bar..."},{0,"Hein ?"},{1,"Rien, rien ! On y va !"},{0,NULL}};
static const L i6[]={{2,"Le château des ducs, ses tours illuminées dans la nuit."},{1,"Tu veux que je te porte pour mieux chercher ?"},{0,"Haha, non, on cherche des traces !"},{0,NULL}};
static const L n6[]={
 {3,"Qui va là ?! Ah, c'est vous ! Je monte la garde avec mon sabre."},
 {0,"Gabin ?! Mais tu étais dans ma rue tout à l'heure !"},
 {3,"Je suis très rapide. Ninja du sabre."},
 {1,"Bref. Tu as vu un chat noir ?"},
 {3,"Seulement une ombre qui courait vers les quais de Loire."},
 {3,"Mais pour passer, il faut attraper des gâteaux ! C'est la règle du château."},{0,NULL}};
static const L o6[]={{0,"Les quais de Loire... j'ai un mauvais pressentiment."},{1,"On va le retrouver, je te le promets."},{0,NULL}};
static const L i7[]={{2,"Les quais de Loire, il fait nuit noire. L'eau scintille doucement."},{0,"Onyx... où es-tu mon petit chat..."},{1,"Viens, on cherche encore un peu, ensemble."},{0,NULL}};
static const L n7[]={
 {7,"Keï ? Esteban ? Qu'est-ce que vous faites ici si tard ?"},
 {0,"Sasha... on a cherché Onyx dans toute la ville, en vain."},
 {7,"Ne baisse pas les bras. Les chats reviennent toujours là où ils sont bien."},
 {1,"Là où ils sont bien... Keï, et si on rentrait chez toi ?"},
 {0,"Tu crois ?"},
 {7,"Dernier défi avant de rentrer : un petit jeu de mémoire pour le courage !"},{0,NULL}};
static const L o7[]={{0,"D'accord, rentrons. On regardera mieux chez moi."},{1,"Je suis avec toi, quoi qu'il arrive."},{0,NULL}};
static const L i8[]={{2,"Retour à la maison de Keï, à Bouguenais. Tout est calme."},{1,"Cherchons les jouets d'Onyx, ça le fera peut-être sortir."},{0,NULL}};
static const L o8[]={{0,"J'ai tout retourné... Esteban, regarde sous le lit."},{1,"Sous le lit ? Allons-y."},{0,NULL}};
static const L eA[]={{1,"Je me mets à genoux... Keï, j'ai une surprise pour toi."},{0,"Ça bouge sous le lit !"},{0,NULL}};
static const L eB[]={
 {1,"Ouah ! Il était là depuis le début !"},
 {0,"ONYX !!! Mon bébé ! Il dormait sous mon lit !"},
 {1,"Tout ce chemin, toute cette quête, pour finalement le trouver chez toi."},
 {0,"Haha ! Je suis tellement soulagée..."},{0,NULL}};
static const L eC[]={
 {1,"Keï, je t'aime. Je suis tellement heureux d'avoir retrouvé Onyx avec toi."},
 {1,"Cette aventure m'a montré une chose : je veux être à tes côtés tout le temps."},
 {1,"Est-ce que tu veux rester avec moi pour la vie ?"},
 {0,"Oui... mille fois oui, mon amour. Je t'aime aussi."},
 {2,"Ils se serrent dans les bras, Onyx ronronne tout près d'eux."},{0,NULL}};
static const L dmiss[]={{2,"Il reste encore des choses à faire ici..."},{0,NULL}};

/* ---------------- niveaux ---------------- */
typedef struct{int id;int x;const L*d;}Npc;
typedef struct{const char*name;int kind;int w;unsigned sky,far,gnd;int nitems;const char*iname;
  const L*intro;Npc n[2];const L*outro;int mini,mt,bgm;}Lv;
enum{KR,KS,KP,KT,KN,KB,KC,KL};
#define N0 {0,0,NULL}
static const Lv LV[9]={
 {"Chapitre 1 - La chambre de Keï",KR,1500,RGB(30,22,50),RGB(30,22,50),RGB(95,60,70),3,"poils noirs",i0,{N0,N0},o0,0,0,0},
 {"Chapitre 2 - Rue de Bouguenais",KS,3000,RGB(30,25,70),RGB(52,40,100),RGB(70,70,90),5,"croquettes",i1,{{3,1700,n1},N0},o1,0,0,0},
 {"Chapitre 3 - Le parc",KP,3200,RGB(15,40,60),RGB(25,70,80),RGB(45,100,60),5,"empreintes",i2,{{4,1900,n2},N0},o2,1,8,0},
 {"Chapitre 4 - Le tram",KT,2400,RGB(20,20,50),RGB(40,40,80),RGB(80,85,110),4,"poils noirs",i3,{{7,1400,n3},N0},o3,0,0,1},
 {"Chapitre 5 - Nantes centre",KN,3400,RGB(40,20,70),RGB(70,40,110),RGB(110,90,100),5,"indices",i4,{{5,2000,n4},N0},o4,2,3,0},
 {"Chapitre 6 - Le Café du cinéma",KB,3000,RGB(60,30,40),RGB(60,30,40),RGB(110,60,50),5,"souvenirs",i5,{{6,1300,n5a},{8,2300,n5b}},o5,0,0,0},
 {"Chapitre 7 - Le château",KC,3400,RGB(25,15,60),RGB(70,50,110),RGB(90,80,100),5,"traces",i6,{{3,2000,n6},N0},o6,1,12,0},
 {"Chapitre 8 - Les quais de Loire",KL,3200,RGB(10,15,45),RGB(25,40,90),RGB(60,60,90),5,"traces d'Onyx",i7,{{7,1800,n7},N0},o7,2,4,1},
 {"Chapitre 9 - Retour à la maison",KR,1500,RGB(30,22,50),RGB(30,22,50),RGB(95,60,70),3,"jouets",i8,{N0,N0},o8,0,0,1}
};

/* ---------------- état ---------------- */
enum{ST_WEL,ST_TITLE,ST_CUT,ST_PLAY,ST_DLG,ST_MINI,ST_FIN};
enum{CTX_INTRO,CTX_NPC,CTX_OUTRO,CTX_MISS,CTX_CS};
static int st=ST_WEL, under=ST_PLAY, lv=0;
static float gt=0, stt=0;
/* dialogue */
static const L*dl; static int di,dctx; static float dch; static int dtot;
static char wl[5][160]; static int wn; static int dnpc=0;
static int cpcount(const char*s){int n=0;for(;*s;s++)if(((unsigned char)*s&0xC0)!=0x80)n++;return n;}
static int cpbytes(const char*s,int n){int b=0,c=0;while(s[b]){if(((unsigned char)s[b]&0xC0)!=0x80){if(c==n)break;c++;}b++;}return b;}
static void wrap(const char*t){
  wn=0; char line[160]=""; char word[80]; const char*p=t;
  while(*p){
    int k=0; while(*p&&*p!=' '&&k<79)word[k++]=*p++; word[k]=0; while(*p==' ')p++;
    char tmp[240]; snprintf(tmp,240,"%s%s%s",line,line[0]?" ":"",word);
    if(tw(1.1f,tmp)>850&&line[0]){ if(wn<4)strcpy(wl[wn++],line); snprintf(line,160,"%s",word);} else snprintf(line,160,"%s",tmp);
  }
  if(wn<5)strcpy(wl[wn++],line);
  dtot=0; for(int i=0;i<wn;i++)dtot+=cpcount(wl[i]);
}
static void dlg_line(void){wrap(dl[di].t);dch=0;}
static void dlg_start(const L*d,int ctx){dl=d;di=0;dctx=ctx;if(st!=ST_DLG)under=st;st=ST_DLG;dlg_line();}

/* joueur */
static float px,py,pz,pvz,anim,ex,ey,eanim; static int pf=1,ef=1;
typedef struct{float x,y;int high,got;}It; static It it[8]; static int ngot; static int talked[2];
static float title_t;
static void start_level(int i){
  lv=i; px=160; py=GTOP+80; pz=pvz=0; ex=60; ey=py; ngot=0; talked[0]=talked[1]=0; pf=1;
  int w=LV[i].w; int n=LV[i].nitems;
  for(int k=0;k<n;k++){ it[k].x=350+k*(w-900)/n+(k*137)%90; it[k].y=GTOP+35+(k*53)%110; it[k].high=(k%2)==1; it[k].got=0; }
  cur_bgm=LV[i].bgm; title_t=3.5f; st=ST_PLAY; dlg_start(LV[i].intro,CTX_INTRO);
}

/* cinématiques */
static int cs_id=0,cs_ph=0; static float cs_t=0,catx=0,cs_ex=1050;
static void cs_start(int id){cs_id=id;cs_ph=0;cs_t=0;catx=560;cs_ex=1050;st=ST_CUT;cur_bgm=(id==0)?1:0;}
static void cs_adv(void){
  cs_ph++; cs_t=0; st=ST_CUT;
  if(cs_id==0){
    if(cs_ph==2)dlg_start(iA,CTX_CS);
    else if(cs_ph==4)dlg_start(iB,CTX_CS);
    else if(cs_ph==5)start_level(0);
  } else {
    if(cs_ph==1)dlg_start(eA,CTX_CS);
    else if(cs_ph==3)dlg_start(eB,CTX_CS);
    else if(cs_ph==5)dlg_start(eC,CTX_CS);
    else if(cs_ph==7){st=ST_FIN;cur_bgm=0;stt=0;}
  }
}
static void after_level(void);
static void dlg_end(void){
  switch(dctx){
    case CTX_INTRO:st=ST_PLAY;break;
    case CTX_NPC:talked[dnpc]=1;st=ST_PLAY;break;
    case CTX_OUTRO:after_level();break;
    case CTX_MISS:st=ST_PLAY;px-=70;break;
    case CTX_CS:st=ST_CUT;cs_adv();break;
  }
}

/* mini-jeux */
static int mtype,mtarget,mst,mscore,mround,slen,sphase,sidx,mflash; static float mtimer,mx,sp_t,stimer; static int seq[8];
typedef struct{float x,y;int type,alive;}Dr; static Dr dr[20];
static void seq_gen(void){for(int i=0;i<slen;i++)seq[i]=rand()%4;sphase=0;stimer=-0.6f;sidx=0;}
static void mini_start(int type,int target){
  mtype=type;mtarget=target;mst=0;mscore=0;mtimer=25;mx=480;sp_t=0;mround=0;
  memset(dr,0,sizeof(dr)); slen=(target>3?5:3)-0; if(type==2)slen=3+(target>3); st=ST_MINI; cur_bgm=1;
}
static void after_level(void){
  if(lv==8){cs_start(1);return;}
  if(LV[lv].mini)mini_start(LV[lv].mini,LV[lv].mt); else start_level(lv+1);
}

/* ---------------- dessin décors ---------------- */
static unsigned hs(unsigned i){return ((i*7919u+13u)*(i*104729u+7u)>>3)%1000u;}
static void cake(float x,float f){
  R(x-32,f-22,64,22,RGB(250,160,200)); R(x-26,f-40,52,18,RGB(255,240,230)); R(x-32,f-24,64,4,RGB(255,255,255));
  R(x-3,f-56,6,16,RGB(120,200,255)); R(x-3,f-66+(int)(gt*8)%2,6,10,RGB(255,200,40));
  R(x-20,f-30,6,6,RGB(220,40,80)); R(x+14,f-30,6,6,RGB(220,40,80));
}
static void balloon(float x,float y,unsigned c){vita2d_draw_fill_circle(x,y,16,c);R(x-1,y+16,2,40,RGB(200,200,200));}
static void paw(float x,float y,unsigned c){
  vita2d_draw_fill_circle(x,y+4,9,c);
  vita2d_draw_fill_circle(x-10,y-6,4,c);vita2d_draw_fill_circle(x-4,y-12,4,c);
  vita2d_draw_fill_circle(x+4,y-12,4,c);vita2d_draw_fill_circle(x+10,y-6,4,c);
}
static void npc_draw(int id,float x,float f){
  unsigned hair,shirt,pants,skin=RGB(240,195,150); float u=1;
  switch(id){
    case 3:hair=RGB(60,40,30);shirt=RGB(60,90,160);pants=RGB(40,40,50);break;
    case 4:hair=RGB(90,60,30);shirt=RGB(225,225,235);pants=RGB(80,70,60);u=.75f;break;
    case 5:hair=RGB(30,30,30);shirt=RGB(255,120,200);pants=RGB(230,230,240);break;
    case 6:hair=RGB(150,90,40);shirt=RGB(60,150,70);pants=RGB(50,60,90);break;
    case 7:hair=RGB(110,60,40);shirt=RGB(170,90,220);pants=RGB(170,90,220);break;
    default:hair=RGB(40,30,20);shirt=RGB(230,150,40);pants=RGB(50,50,70);
  }
  R(x-24,f-3,48,6,RGBA8(0,0,0,90));
  R(x-12*u,f-30*u,24*u,30*u,pants); R(x-14*u,f-62*u,28*u,32*u,shirt);
  R(x-21*u,f-60*u,7*u,26*u,skin); R(x+14*u,f-60*u,7*u,26*u,skin);
  R(x-12*u,f-86*u,24*u,24*u,skin);
  if(id==7){R(x-15*u,f-92*u,30*u,14*u,hair);R(x-15*u,f-80*u,6*u,34*u,hair);R(x+9*u,f-80*u,6*u,34*u,hair);}
  else R(x-13*u,f-92*u,26*u,12*u,hair);
  R(x-7*u,f-76*u,4*u,4*u,RGB(10,10,10)); R(x+3*u,f-76*u,4*u,4*u,RGB(10,10,10));
  R(x-5*u,f-68*u,10*u,2*u,RGB(190,90,90));
  if(id==5)R(x-10*u,f-78*u,20*u,6*u,RGB(0,0,0));
  if(id==4){R(x-10*u,f-79*u,8*u,8*u,RGB(40,40,40));R(x+2*u,f-79*u,8*u,8*u,RGB(40,40,40));}
  if(id==3){R(x+22,f-150,5,110,RGB(210,210,225));R(x+16,f-44,17,5,RGB(200,160,40));}
  if(id==6||id==8){R(x+20,f-48,12,16,RGB(240,190,40));R(x+22,f-52,8,4,RGB(255,255,255));}
}
static void hash_stars(void){
  for(int i=0;i<40;i++){float sx=hs(i*3)*0.96f,sy=hs(i*5)*0.2f;R(sx,sy,3,3,(i+(int)(gt*2))%5?RGB(220,220,255):RGB(120,120,160));}
}
static void decor(const Lv*l,float cam){
  R(0,0,SW,GTOP+10,l->sky);
  if(l->kind==KT){ /* tram */
    R(0,0,SW,GTOP+10,RGB(60,70,100));
    for(int i=0;i<12;i++){float x=i*260-cam;if(x<-260||x>SW)continue;
      R(x+20,30,200,120,RGB(20,20,45));
      for(int j=0;j<6;j++)R(x+30+((j*47+(int)(gt*160))%180),60+j*14,6,4,RGB(255,220,120));
      R(x+16,26,208,6,RGB(180,180,200));}
    R(0,170,SW,8,RGB(180,180,200));
  } else if(l->kind==KB){ /* bar */
    R(0,0,SW,GTOP+10,RGB(65,32,40));
    for(int i=0;i<8;i++){float x=i*420-cam*0.9f;if(x<-420||x>SW)continue;
      R(x+30,50,150,100,RGB(30,20,50));R(x+36,56,138,88,RGB(255,240,200)); /* affiche ciné */
      R(x+60,70,90,10,RGB(200,40,60));R(x+60,90,70,6,RGB(60,60,80));
      R(x+260,60,6,120,RGB(160,120,60));R(x+260,60,80,6,RGB(160,120,60));
      for(int b=0;b<6;b++)R(x+270+b*12,40+(b%2)*6,8,22,RGB(80+b*20,140,90));}
    float nx=640-cam*0.9f; R(nx,20,300,34,RGB(40,0,30));
    ctxt(nx+150,46,(((int)(gt*3))%7)?RGB(255,80,200):RGB(120,40,100),1.0f,"LE CAFÉ DU CINÉMA");
  } else {
    hash_stars();
    if(l->kind==KL)R(0,GTOP-35,SW,35,RGB(25,60,130));
    float off=cam*0.4f; int base=(int)(off/160);
    for(int i=0;i<8;i++){int idx=base+i;float x=idx*160-off;int hh=60+hs(idx)%110;
      if(l->kind==KP){ /* arbres */
        R(x+60,GTOP-hh,16,hh,RGB(70,45,30)); vita2d_draw_fill_circle(x+68,GTOP-hh,48,l->far);
      } else {
        R(x,GTOP-hh+20,140,hh,l->far);
        for(int wy=0;wy<hh-30;wy+=24)for(int wx=12;wx<130;wx+=34)
          if(hs(idx*31+wy+wx)%3)R(x+wx,GTOP-hh+34+wy,10,12,RGB(255,220,120));
        if(l->kind==KC&&hs(idx)%3==0){R(x+20,GTOP-hh-30,20,30,l->far);R(x+90,GTOP-hh-30,20,30,l->far);}
      }
    }
    vita2d_draw_fill_circle(820,70,34,RGB(250,245,200));
  }
  R(0,GTOP,SW,SH-GTOP,l->gnd);
  for(int i=0;i<16;i++){float x=i*80-fmodf(cam,80);R(x,GTOP+30+(i%3)*50,40,4,RGBA8(0,0,0,50));}
  R(0,GTOP,SW,6,RGBA8(255,255,255,40));
}
static void decor_world(const Lv*l,float cam){
  if(l->kind==KR){ /* fenêtre + lit */
    R(200-cam,40,160,120,RGB(15,15,40));R(206-cam,46,148,108,RGB(25,30,80));vita2d_draw_fill_circle(300-cam,90,22,RGB(250,245,200));
    R(280-cam,46,4,108,RGB(95,60,70));
    R(950-cam,GTOP+40,380,40,RGB(120,80,60));R(960-cam,GTOP+10,360,40,RGB(230,180,200));R(960-cam,GTOP-10,70,28,RGB(255,255,255));
  }
  if(l->kind==KB){ /* comptoir */
    R(1700-cam,GTOP+4,760,26,RGB(120,70,40));R(1700-cam,GTOP+30,760,40,RGB(80,45,30));
    for(int i=0;i<12;i++)R(1720+i*60-cam,GTOP-18,12,22,RGB(40+i*15,150,90));
  }
  if(l->kind!=KT&&l->kind!=KR){
    for(int x=300;x<l->w;x+=450){float sx=x-cam;if(sx<-40||sx>SW+40)continue;
      if(l->kind!=KB){R(sx,GTOP-60,6,70,RGB(60,60,70));vita2d_draw_fill_circle(sx+3,GTOP-64,10,RGB(255,225,140));}}
  }
  /* bannière et ballons */
  for(int x=100;x<l->w;x+=130){float sx=x-cam;if(sx<-30||sx>SW+30)continue;
    R(sx,GTOP-190+((x/130)%2)*10,24,20,(x/130)%3==0?RGB(255,120,180):((x/130)%3==1?RGB(255,220,80):RGB(120,200,255)));}
  for(int k=0;k*900+650<l->w-200;k++){float x=650+k*900;float sx=x-cam;
    if(sx<-80||sx>SW+80)continue;
    cake(sx,GTOP+55);balloon(sx-60,GTOP-60+sinf(gt*2+k)*4,RGB(255,100,160));balloon(sx+60,GTOP-70+cosf(gt*2+k)*4,RGB(120,200,255));}
  if(l->kind==KB){cake(2900-cam,GTOP+60);cake(2200-cam,GTOP+120);}
}

/* ---------------- logique du jeu (niveau) ---------------- */
static int done(void){
  const Lv*l=&LV[lv]; if(ngot<l->nitems)return 0;
  for(int i=0;i<2;i++)if(l->n[i].d&&!talked[i])return 0; return 1;
}
static void play_update(void){
  const Lv*l=&LV[lv];
  float sp=(pad.buttons&(SCE_CTRL_RTRIGGER|SCE_CTRL_LTRIGGER))?240:150; int mv=(ax!=0||ay!=0);
  px+=ax*sp*DT; py+=ay*sp*0.6f*DT;
  if(px<60)px=60; if(px>l->w-30)px=l->w-30; if(py<GTOP+20)py=GTOP+20; if(py>GBOT)py=GBOT;
  if(ax>0.1f)pf=1; if(ax<-0.1f)pf=-1;
  if(mv)anim+=DT*(sp>200?12:8);
  if((pr&SCE_CTRL_CROSS)&&pz<=0){pvz=400;sfx(1);}
  pz+=pvz*DT; pvz-=1150*DT; if(pz<0){pz=0;pvz=0;}
  float tx=px-60*pf; float d=tx-ex; ex+=d*3*DT; ey+=(py-8-ey)*3*DT;
  if(d>6)ef=1; if(d<-6)ef=-1; if(fabsf(d)>8)eanim+=DT*8;
  for(int i=0;i<l->nitems;i++)if(!it[i].got&&fabsf(px-it[i].x)<48&&fabsf(py-it[i].y)<50&&(!it[i].high||pz>25)){it[i].got=1;ngot++;sfx(2);}
  if(title_t>0)title_t-=DT;
  if(pr&SCE_CTRL_CIRCLE)for(int i=0;i<2;i++)if(l->n[i].d&&fabsf(px-l->n[i].x)<90&&fabsf(py-(GBOT-30))<90){dnpc=i;sfx(0);dlg_start(l->n[i].d,CTX_NPC);return;}
  if(px>l->w-100){ if(done()){sfx(0);dlg_start(l->outro,CTX_OUTRO);} else {sfx(0);dlg_start(dmiss,CTX_MISS);} }
}
static void draw_kei(float cx,float fy,int moving,int run,float z){
  int t=K_FRONT; if(z>2)t=K_R1; else if(moving)t=(run?K_R0:K_W0)+((int)anim&3);
  R(cx-22,fy-3,44,6,RGBA8(0,0,0,90)); spr(t,cx,fy-z,pf<0,1.0f);
}
static void draw_play(void){
  const Lv*l=&LV[lv]; float cam=px-480; if(cam<0)cam=0; if(cam>l->w-SW)cam=l->w-SW;
  decor(l,cam); decor_world(l,cam);
  for(int i=0;i<l->nitems;i++)if(!it[i].got){
    float sx=it[i].x-cam,sy=it[i].y-(it[i].high?70:0)+sinf(gt*4+i)*4;
    R(sx-14,it[i].y-3,28,6,RGBA8(0,0,0,70)); paw(sx,sy,RGB(255,190,230));
  }
  for(int i=0;i<2;i++)if(l->n[i].d){npc_draw(l->n[i].id,l->n[i].x-cam,GBOT-30);
    if(fabsf(px-l->n[i].x)<90&&fabsf(py-(GBOT-30))<90&&st==ST_PLAY){
      ctxt(l->n[i].x-cam,GBOT-130,RGB(255,255,255),1.0f,"O : parler");}}
  /* persos triés par profondeur */
  float kx=px-cam,ex2=ex-cam; int run=(pad.buttons&(SCE_CTRL_RTRIGGER|SCE_CTRL_LTRIGGER))!=0; int mv=(ax!=0||ay!=0);
  if(ey<py){
    R(ex2-22,ey-3,44,6,RGBA8(0,0,0,90)); spr(fabsf(ex-(px-60*pf))>8?E_W0+((int)eanim&1):E_IDLE,ex2,ey,ef<0,0.9f);
    draw_kei(kx,py,mv,run,pz);
  } else {
    draw_kei(kx,py,mv,run,pz);
    R(ex2-22,ey-3,44,6,RGBA8(0,0,0,90)); spr(fabsf(ex-(px-60*pf))>8?E_W0+((int)eanim&1):E_IDLE,ex2,ey,ef<0,0.9f);
  }
  /* sortie */
  if(px>l->w-700){float sx=l->w-60-cam; R(sx,GTOP-70,14,110,done()?RGB(120,255,160):RGB(130,130,150));
    ctxt(sx-30,GTOP-80,done()?RGB(120,255,160):RGB(200,200,220),1.0f,done()?"Sortie >>":"Sortie (fermée)");}
  /* HUD */
  R(10,10,330,62,RGBA8(0,0,0,150));
  char b[128]; snprintf(b,128,"%s : %d/%d",l->iname,ngot,l->nitems); txt(20,34,RGB(255,220,240),1.0f,b);
  int nn=0,tt=0;for(int i=0;i<2;i++)if(l->n[i].d){nn++;tt+=talked[i];}
  if(nn){snprintf(b,128,"Discussions : %d/%d",tt,nn);txt(20,58,RGB(200,230,255),1.0f,b);}
  else txt(20,58,RGB(200,230,255),0.9f,"X sauter  R/L courir");
  if(title_t>0){int a=title_t>1?255:(int)(title_t*255);R(0,200,SW,70,RGBA8(0,0,0,(int)(a*0.6f)));ctxt(SW/2,245,RGBA8(255,255,255,a),1.5f,l->name);}
}

/* ---------------- cinématiques ---------------- */
static void room_scene(void){
  R(0,0,SW,SH,RGB(40,30,60)); R(0,300,SW,SH-300,RGB(95,60,70));
  R(100,60,200,150,RGB(15,15,40));R(108,68,184,134,RGB(25,30,80));vita2d_draw_fill_circle(240,110,22,RGB(250,245,200));R(196,68,4,134,RGB(95,60,70));
  hash_stars();
  for(int i=0;i<10;i++)R(40+i*96,30,24,20,i%3==0?RGB(255,120,180):(i%3==1?RGB(255,220,80):RGB(120,200,255)));
  R(280,300,440,90,RGB(120,80,60)); R(276,240,22,150,RGB(100,64,48)); R(290,285,420,50,RGB(235,200,215)); R(300,276,80,30,RGB(255,255,255));
  cake(820,330);cake(120,340);
}
static void draw_cut(void){
  room_scene();
  if(cs_id==0){
    if(cs_ph<2){ if(T[K_FRONT])vita2d_draw_texture_rotate(T[K_FRONT],385,282,-1.5708f); } else spr(K_FRONT,385,338,0,1.0f);
    R(372,296,330,52,RGB(90,120,200)); R(372,296,330,8,RGB(130,160,235));
    if(cs_ph==0){ spr(O_SIT,560,300,0,1.0f); ctxt(430,250-sinf(gt*3)*6,RGB(200,220,255),1.4f,"Z z z"); heart(380,200,5,RGB(255,120,160)); }
    if(cs_ph==1){ float y=catx<640?300:300+fminf(80,(catx-640)*0.8f); spr(O_R0+((int)(gt*12)&3),catx,y,0,1.0f); }
    if(cs_ph>=3&&cs_ph<5) spr(E_W0+((int)(gt*8)&1),cs_ex,GBOT,1,0.95f);
  } else {
    R(300,338,400,52,RGB(8,4,16));
    if(cs_ph>=2){float rise=cs_ph==2?fminf(1,cs_t/1.5f):1; spr(O_FACE,500,420-30*rise,0,0.55f);}
    if(cs_ph<6){ spr(K_SIDE,790,GBOT+8,1,1.0f); spr(E_IDLE,230,GBOT+8,0,0.95f); }
    else {
      spr(E_IDLE,430,GBOT+8,0,0.95f); spr(K_FRONT,486,GBOT+8,0,1.0f); spr(O_SIT,600,GBOT+8,0,1.2f);
      for(int i=0;i<8;i++){float t=fmodf(gt*0.5f+i*0.13f,1.0f);heart(380+i*40,330-t*220,4,RGBA8(255,100,150,(int)(255*(1-t))));}
    }
  }
}

/* ---------------- dialogue ---------------- */
static void draw_dlg(void){
  R(14,402,932,132,RGB(255,255,255)); R(18,406,924,124,RGBA8(12,6,30,250));
  const char*nm=SPK[dl[di].who];
  if(nm[0]){float w=tw(1.1f,nm)+30; R(30,378,w,34,RGB(255,255,255)); R(33,381,w-6,28,RGB(70,20,110)); txt(45,404,RGB(255,255,255),1.1f,nm);}
  int rem=(int)dch;
  for(int i=0;i<wn&&rem>0;i++){
    int cp=cpcount(wl[i]); int take=rem<cp?rem:cp; char buf[160]; int bb=cpbytes(wl[i],take);
    memcpy(buf,wl[i],bb); buf[bb]=0; txt(40,446+i*30,RGB(255,255,255),1.1f,buf); rem-=take;
  }
  if(dch>=dtot&&((int)(gt*3)&1)){R(900,506,18,8,RGB(255,220,80));R(904,514,10,6,RGB(255,220,80));}
}

/* ---------------- mini-jeux ---------------- */
static void mini_update(void){
  if(mst==0){ if(OK){sfx(0);mst=1;if(mtype==2){mround=0;seq_gen();} } return; }
  if(mst>=2){ if(OK){sfx(0); if(mst==2)start_level(lv+1); else mini_start(mtype,mtarget);} return; }
  if(mtype==1){
    mx+=ax*430*DT; if(mx<50)mx=50; if(mx>910)mx=910;
    mtimer-=DT; sp_t-=DT;
    if(sp_t<=0){ sp_t=0.5f; for(int i=0;i<20;i++)if(!dr[i].alive){dr[i].alive=1;dr[i].x=50+rand()%860;dr[i].y=-20;int r=rand()%10;dr[i].type=r<2?2:(r<4?1:0);break;} }
    for(int i=0;i<20;i++)if(dr[i].alive){
      dr[i].y+=(200+mtarget*9)*DT;
      if(dr[i].y>430&&dr[i].y<520&&fabsf(dr[i].x-mx)<50){dr[i].alive=0;
        if(dr[i].type==0){mscore++;sfx(2);} else if(dr[i].type==1){mscore+=2;sfx(2);} else {mscore--;if(mscore<0)mscore=0;sfx(1);} }
      else if(dr[i].y>560)dr[i].alive=0;
    }
    if(mtimer<=0)mst=(mscore>=mtarget)?2:3;
  } else {
    if(mflash>0)mflash--;
    if(sphase==0){ float pv=stimer; stimer+=DT; int a=(int)floorf(pv/0.8f),b=(int)floorf(stimer/0.8f);
      if(b!=a&&b>=0&&b<slen)sfx(0); if(stimer>=slen*0.8f+0.4f){sphase=1;sidx=0;} }
    else { int b=-1; if(pr&SCE_CTRL_CROSS)b=0; else if(pr&SCE_CTRL_CIRCLE)b=1; else if(pr&SCE_CTRL_SQUARE)b=2; else if(pr&SCE_CTRL_TRIANGLE)b=3;
      if(b>=0){ if(b==seq[sidx]){sfx(2);sidx++; if(sidx>=slen){mround++; if(mround>=3)mst=2; else {slen++;seq_gen();}}}
                else {mflash=45;sfx(1);seq_gen();} } }
  }
}
static void draw_mini(void){
  R(0,0,SW,SH,RGB(25,15,50)); hash_stars(); R(0,470,SW,74,RGB(70,45,90));
  if(mst==0){
    ctxt(SW/2,100,RGB(255,220,240),1.8f,"MINI-JEU");
    if(mtype==1){ ctxt(SW/2,170,RGB(255,255,255),1.5f,"Attrape les gâteaux !");
      ctxt(SW/2,240,RGB(220,220,255),1.1f,"Stick ou croix : bouger");
      ctxt(SW/2,275,RGB(220,220,255),1.1f,"Gâteau +1   Cœur +2   Bière -1");
      char b[96]; snprintf(b,96,"Objectif : %d points en 25 secondes",mtarget); ctxt(SW/2,310,RGB(255,220,120),1.1f,b); }
    else { ctxt(SW/2,170,RGB(255,255,255),1.5f,"Les pas d'Onyx");
      ctxt(SW/2,240,RGB(220,220,255),1.1f,"Retiens la suite de boutons, puis refais-la.");
      ctxt(SW/2,275,RGB(220,220,255),1.1f,"X  O  Carré  Triangle - 3 manches");}
    if((int)(gt*2)&1)ctxt(SW/2,430,RGB(255,255,255),1.2f,"X : commencer");
    return;
  }
  if(mst==2){ ctxt(SW/2,220,RGB(255,230,120),1.8f,"Bravo !"); heart(SW/2-35,260,10,RGB(255,100,150)); if((int)(gt*2)&1)ctxt(SW/2,430,RGB(255,255,255),1.2f,"X : continuer"); return; }
  if(mst==3){ ctxt(SW/2,220,RGB(255,150,150),1.8f,"Presque ! Réessaie"); if((int)(gt*2)&1)ctxt(SW/2,430,RGB(255,255,255),1.2f,"X : réessayer"); return; }
  if(mtype==1){
    for(int i=0;i<20;i++)if(dr[i].alive){float x=dr[i].x,y=dr[i].y;
      if(dr[i].type==0){R(x-14,y-8,28,16,RGB(250,160,200));R(x-14,y-12,28,6,RGB(255,245,235));R(x-2,y-22,4,10,RGB(255,210,60));}
      else if(dr[i].type==1)heart(x-14,y-12,4,RGB(255,80,120));
      else {R(x-11,y-14,22,28,RGB(240,190,40));R(x-11,y-14,22,7,RGB(255,255,255));R(x+11,y-8,8,16,RGB(240,190,40));}}
    spr(K_R0+((int)(gt*10)&3),mx,520,0,1.0f);
    char b[96]; snprintf(b,96,"Score : %d / %d   Temps : %d",mscore,mtarget,(int)mtimer+1); txt(20,40,RGB(255,255,255),1.2f,b);
  } else {
    unsigned cols[4]={RGB(80,120,255),RGB(255,80,100),RGB(255,140,220),RGB(80,220,130)};
    const char*nm[4]={"X","O","Carré","Triangle"};
    int hl=-1; if(sphase==0&&stimer>=0&&stimer<slen*0.8f&&fmodf(stimer,0.8f)<0.6f)hl=seq[(int)(stimer/0.8f)];
    for(int i=0;i<4;i++){float x=60+i*215; R(x,180,190,150,hl==i?cols[i]:RGBA8(60,50,90,255)); R(x+6,186,178,138,hl==i?RGB(255,255,255):RGB(35,25,60)); ctxt(x+95,265,hl==i?cols[i]:RGB(150,140,190),1.4f,nm[i]);}
    char b[96]; snprintf(b,96,"Manche %d / 3",mround+1); txt(20,40,RGB(255,255,255),1.2f,b);
    ctxt(SW/2,400,sphase==0?RGB(255,220,120):RGB(120,255,160),1.3f,sphase==0?"Regarde bien...":"À toi !");
    if(sphase==1)for(int i=0;i<slen;i++)R(SW/2-slen*18+i*36,430,24,12,i<sidx?RGB(120,255,160):RGB(90,80,120));
    if(mflash>0)ctxt(SW/2,150,RGB(255,120,120),1.3f,"Raté ! On recommence la manche");
  }
}

/* ---------------- écrans ---------------- */
static void draw_wel(void){
  R(0,0,SW,SH,RGB(0,0,0));
  const char*ln[4]={"Bienvenue Boubouille,","ce jeu a été créé par 7D","pour te dire son amour pour toi","je t'aime"};
  float t0[4]={0.8f,2.6f,4.4f,6.4f};
  for(int i=0;i<4;i++){ float a=(stt-t0[i])*1.2f; if(a<=0)continue; if(a>1)a=1;
    unsigned c=i==0?RGBA8(255,150,220,(int)(a*255)):(i==3?RGBA8(255,90,120,(int)(a*255)):RGBA8(255,255,255,(int)(a*255)));
    ctxt(SW/2,150+i*70,c,i==3?2.0f:1.5f,ln[i]); }
  if(stt>7){heart(SW/2-35,440,10,RGB(255,60,100)); }
  if(stt>7&&((int)(gt*2)&1))ctxt(SW/2,520,RGB(180,180,180),1.0f,"X : continuer");
}
static void draw_title(void){
  R(0,0,SW,SH,RGB(10,5,25)); hash_stars();
  if(T[PFP])vita2d_draw_texture_scale(T[PFP],SW/2-150,30,2.35f,2.35f);
  ctxt(SW/2,400,RGB(255,200,235),2.0f,"A la quête d'Onyx");
  ctxt(SW/2,445,RGB(200,200,255),1.0f,"Un jeu pour Keï - de la part de 7D");
  if((int)(gt*2)&1)ctxt(SW/2,500,RGB(255,255,255),1.2f,"Appuie sur X");
}
static void draw_fin(void){
  R(0,0,SW,SH,RGB(0,0,0)); hash_stars();
  for(int i=0;i<12;i++){float t=fmodf(stt*0.3f+i*0.083f,1.0f);heart(40+i*78,520-t*500,5,RGBA8(255,100,150,(int)(255*(1-t))));}
  if(T[KO_SELFIE])spr(KO_SELFIE,480,300,0,1.6f);
  for(int i=0;i<5;i++)cake(120+i*180,520);
  float a=fminf(1,stt/2); 
  ctxt(SW/2,350,RGBA8(255,150,220,(int)(a*255)),1.7f,"Je t'aime Boubouille");
  ctxt(SW/2,395,RGBA8(255,255,255,(int)(a*255)),1.7f,"Bon anniversaire");
  if(stt>10&&((int)(gt*2)&1))ctxt(SW/2,455,RGB(180,180,180),1.0f,"X : rejouer");
}

/* ---------------- boucle principale ---------------- */
static void update(void){
  switch(st){
    case ST_WEL: stt+=DT; if(OK&&stt>1){sfx(0); if(stt<7)stt=7; else {st=ST_TITLE;stt=0;}} break;
    case ST_TITLE: if(OK){sfx(0);cs_start(0);} break;
    case ST_CUT:
      cs_t+=DT;
      if(cs_id==0){ if(cs_ph==0&&cs_t>4)cs_adv(); else if(cs_ph==1){catx+=420*DT; if(catx>1050)cs_adv();} else if(cs_ph==3){cs_ex-=160*DT; if(cs_ex<=620)cs_adv();} }
      else { if(cs_ph==0&&cs_t>1.2f)cs_adv(); else if(cs_ph==2&&cs_t>2.5f)cs_adv(); else if(cs_ph==4&&cs_t>1.5f)cs_adv(); else if(cs_ph==6&&cs_t>8)cs_adv(); }
      break;
    case ST_PLAY: play_update(); break;
    case ST_DLG:
      dch+=45*DT;
      if(OK){ sfx(0); if(dch<dtot)dch=dtot; else { di++; if(!dl[di].t)dlg_end(); else dlg_line(); } }
      break;
    case ST_MINI: mini_update(); break;
    case ST_FIN: stt+=DT; if(OK&&stt>3){sfx(0);st=ST_TITLE;cur_bgm=1;} break;
  }
}
static void render(void){
  switch(st){
    case ST_WEL: draw_wel(); break;
    case ST_TITLE: draw_title(); break;
    case ST_CUT: draw_cut(); break;
    case ST_PLAY: draw_play(); break;
    case ST_DLG: if(under==ST_PLAY)draw_play(); else draw_cut(); draw_dlg(); break;
    case ST_MINI: draw_mini(); break;
    case ST_FIN: draw_fin(); break;
  }
}
int main(void){
  vita2d_init(); vita2d_set_clear_color(RGB(0,0,0));
  F=vita2d_load_default_pgf();
  for(int i=0;i<NT;i++){char p[96];snprintf(p,96,"app0:assets/%s.png",TN[i]);T[i]=vita2d_load_PNG_file(p);
    if(T[i])vita2d_texture_set_filters(T[i],SCE_GXM_TEXTURE_FILTER_POINT,SCE_GXM_TEXTURE_FILTER_POINT);}
  wav[0]=loadwav("bgm.wav",&wlen[0]); wav[1]=loadwav("bgm2.wav",&wlen[1]);
  wav[2]=loadwav("blip.wav",&wlen[2]); wav[3]=loadwav("jump.wav",&wlen[3]); wav[4]=loadwav("item.wav",&wlen[4]);
  cur_bgm=1;
  SceUID t1=sceKernelCreateThread("bgm",bgm_thread,0x10000100,0x10000,0,0,NULL); sceKernelStartThread(t1,0,NULL);
  SceUID t2=sceKernelCreateThread("sfx",sfx_thread,0x10000100,0x10000,0,0,NULL); sceKernelStartThread(t2,0,NULL);
  sceCtrlSetSamplingMode(SCE_CTRL_MODE_ANALOG);
  srand(12345);
  while(1){
    input(); gt+=DT; update();
    vita2d_start_drawing(); vita2d_clear_screen(); render(); vita2d_end_drawing(); vita2d_swap_buffers();
  }
  return 0;
}
